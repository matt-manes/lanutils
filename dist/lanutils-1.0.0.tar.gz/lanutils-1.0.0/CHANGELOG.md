# Changelog

## v0.0.3 (2023-02-11)

#### Fixes

* set privileged to False in ip_is_alive() for linux compatibility


## v0.0.2 (2023-02-11)

#### Fixes

* add "wlo1" to get_myip default adapters_to_find
#### Others

* build v0.0.2
* update changelog
* update readme


## v0.0.1 (2023-02-11)

#### Others

* build v0.0.1
* update __init__.py


## v0.0.0 (2023-02-11)

#### Others

* build v0.0.0
* delete docs